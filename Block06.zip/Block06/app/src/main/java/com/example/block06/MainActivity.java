package com.example.block06;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ImageView imageView_large = (ImageView) findViewById(R.id.imageView_large);
        imageView_large.setImageResource(R.drawable.abc);

        SeekBar tuner = (SeekBar) findViewById(R.id.seekBar_tuner);
        tuner.setOnSeekBarChangeListener(new seekBar.OnSeekBarChangeListener(){
            int lastPregress;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser){
                lastPregress = progress
            }

            @Override
            public void onStartTrakingTouch(SeekBar seekBar){

            }
            @Override
            public void onStopTrakingTouch(SeekBar seekBar){
                imageView_large.setColorFilter(Color.argb(255, 0, lastPregress, 255-lastPregress));
            }
        });
    }
}
